# GenTiny

URL shortener

<h3> Execution: </h3>

* apt-get install python3

* apt-get install git

* git clone https://github.com/AngelSecurityTeam/GenTiny

* cd GenTiny

* pip3 install requests

* python3 gentiny.py URL o python3 gentiny2.py

<img src="https://github.com/AngelSecurityTeam/GenTiny/blob/master/img/gentiny.png">

<img src="https://github.com/AngelSecurityTeam/GenTiny/blob/master/img/gentiny2.png">

<h3> Paypal donations: </h3>

* https://www.paypal.me/AngelSecurityTeam
