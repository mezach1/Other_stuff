# EasyPeasey
Metasploit/MSFVenom Payload Generator Stand Alone

##EasyPeasey takes the frustration and uncertainty of typing console commands out of your hands
##Run EasyPeasey by typing "python EZPZ.py" or "python /$PATH/EZPZ.py"

As of March 26th, 2017, incorporates payloads available on Metasploit, including but not limited to...
    Windows
    Mac OSX
    Android
    Linux
    Java
    Ruby

## Requires Termcolors, Python 2.7.13, and Python-Pip
##Run the dependencyInstaller.sh script file if you don't have any the three aforementioned packages
## Run EZPZ_Installer.sh if you want the program to be run from command line as "EZPZ.py"
## It will automatically make a /root/ArmsCommander directory and drop the files in there. 
