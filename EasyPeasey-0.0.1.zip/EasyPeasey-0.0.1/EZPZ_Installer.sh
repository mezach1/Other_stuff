mkdir /root/ArmsCommander
cp -r ./ /root/ArmsCommander
chmod 777 EZPZ.py
cp -r EZPZ /usr/local/bin
