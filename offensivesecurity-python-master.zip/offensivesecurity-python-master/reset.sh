#!/bin/sh

echo "Resetting IP tables ..."
iptables --flush