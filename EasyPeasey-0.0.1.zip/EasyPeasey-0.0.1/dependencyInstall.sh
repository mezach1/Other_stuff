sudo apt-get update
sudo apt-get install python python-pip
sudo pip install termcolor
